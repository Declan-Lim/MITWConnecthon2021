#include "requestmapper.h"
#include "global.h"
//http://localhost:8080/files/CSV_FHIR.html
//https://www.twblogs.net/a/5ef84632dd98af7e2c490005
RequestMapper::RequestMapper(QObject* parent)
    : HttpRequestHandler(parent) {
    //CSV_PATH = "../query.output.exome_summary.csv";
    CSV_PATH = "../gene_reduced.csv";
    Observe.ReadCSV(CSV_PATH);
    Observe.ReadExampleJson("../Observation.json");
    Observe.ReadLibrary("../hgnc_complete_set.json");
    Molecular.ReadCSV(CSV_PATH);
    Molecular.ReadExampleJson("../MolecularSequence.json");
    BundlePath_Obs = "../Bundle_Observation.json";
    BundlePath_Mol = "../Bundle_Molecular.json";
    limit =10;
}

void RequestMapper::service(HttpRequest& request, HttpResponse& response) {
    QByteArray path=request.getPath();
    qDebug("RequestMapper: path=%s",path.data());

    if (path.startsWith("/files")) {
        staticFileController->service(request,response);
    }
    else if(path=="/parseJSON"){ // occur when submit button clicked
        //new PATIENT and SPECIMEN created at html
        //get HTTP request value from here
        QMap<QString,QString>formValue;
        QByteArray reqBody;
        reqBody = request.getBody();
        QStringList str = QString(reqBody).split("&");
        QString tempName,strToFind,reqBodyStr;
        //All value from form inserted to map
        for(int i=0;i<str.length();i++){
            switch(i){
            case 0:
                strToFind="Patient=";
                tempName = "ID";
                break;
            case 1:
                strToFind="Sample=";
                tempName = "Sample";
                break;
            case 2:
                strToFind="Sequence=";
                tempName = "Sequence";
                break;
            case 3:
                strToFind="Analyse=";
                tempName = "Analyse";
                break;
            case 4:
                strToFind="Module=";
                tempName = "Module";
                break;
            case 5:
                strToFind="Genome=";
                tempName = "Genome";
                break;
            case 6:
                strToFind="WindowRange=";
                tempName = "WindowRange";
                break;
            case 7:
                strToFind="Coordinate=";
                tempName = "Coordinate";
                break;
            case 8:
                strToFind="Strand=";
                tempName = "Strand";
                break;
            case 9:
                strToFind="Source=";
                tempName = "Source";
                break;
            case 10:
                strToFind="Genomic_Selected_Value=";
                tempName = "Genomic_Display";
                break;
            }
            str[i].remove(strToFind);
            /*if(i==0){
                QStringList temp = str[i].split("+%2C+");
                for(int k=0;k<temp.length();k++){
                    if(k==0)formValue.insert(tempName,temp[k]);
                    else{
                        tempName = "Name";
                        formValue.insert(tempName,temp[k]);
                    }
                }
            }
            else{*/
                formValue.insert(tempName,str[i]);
                reqBodyStr += tempName+":"+formValue[tempName]+"\n";
            //}
        }
        //can start forming JSON data
        //Observation starts here ----------------------------------------
        response.write(reqBodyStr.toUtf8(),true);
        Observe.Initialize(formValue["ID"],formValue["Sample"],formValue["Analyse"],formValue["Source"],formValue["Genomic_Display"]);
        QStringList ObserveJson;
        QString JsonData_obs;
        for(int row = 0;row<Observe.RowCount;row++){
            JsonData_obs = Observe.JsonString(Observe.FormJson(Observe.GCol[row],Observe.JCol[row]));
            //qDebug().noquote()<<JsonData_obs<<endl;
            ObserveJson.append(JsonData_obs);
        }
        //Observation ends here ------------------------------------------

        Molecular.Initialize(formValue["ID"],formValue["Sample"],formValue["Sequence"],formValue["Genome"],formValue["WindowRange"],formValue["Coordinate"],formValue["Strand"]);
        //response.write(Molecular.example_str.toUtf8());
        QStringList MolecularJson;
        QString JsonData_mol;
        for(int index=0;index<Molecular.dataVal.size();index++){
            JsonData_mol = Molecular.JsonString(Molecular.FormJson(Molecular.dataVal[index],index));
            MolecularJson.append(JsonData_mol);
            index = Molecular.Current;
            //qDebug().noquote()<<JsonData_mol<<endl;
        }
        //Molecular ends here ------------------------------------------

        /*QString s = "ObserveJson : "+QString::number(ObserveJson.size())+"  MolecularJson :"+QString::number(MolecularJson.size());
        qDebug()<<s;*/
        //theUrl = "http://203.64.84.213:8080/fhir/";
        //theUrl = "http://203.64.84.213:52888/r4/fhir/";

        //http://192.168.50.5:10050/fhir
        QString postURL ="http://192.168.50.5:10050/api";
        qDebug()<<"------------Observation--------------"<<endl;
        //qDebug().noquote()<<ObserveJson.first();
        handler.PostData(postURL+"/Observation",ObserveJson.first());
        bool done;
        int counter=0;
        QString val;
        QFile file_Obs(BundlePath_Obs);
        if(file_Obs.open(QIODevice::ReadOnly | QIODevice::Text)){
            val = file_Obs.readAll();
            file_Obs.close();
            QJsonDocument doc = QJsonDocument::fromJson(val.toUtf8());
            Bundle  = doc.object();
            QJsonObject templateHolder = Bundle;
            QJsonArray nodeArray = Bundle["entry"].toArray();
            QJsonObject nodeTemplate = nodeArray[0].toObject();
            QJsonArray valArr;
            QJsonObject temp;
            for(int i=0;i<ObserveJson.size();i++){
                //form Observation Bundle
                done=false;
                QJsonDocument convert = QJsonDocument::fromJson(ObserveJson[i].toUtf8());
                QJsonObject obj = convert.object();
                temp = nodeTemplate;
                temp["resource"] = obj;
                valArr.append(temp);
                counter++;
                if(counter==limit){
                    Bundle["entry"] = valArr;
                    //qDebug().noquote()<<Observe.JsonString(Bundle);
                    //handler.PostData(postURL,Observe.JsonString(Bundle));
                    Bundle = templateHolder;
                    nodeArray = Bundle["entry"].toArray();
                    nodeTemplate = nodeArray[0].toObject();
                    if(!valArr.empty()){
                        for(int index=0;index<counter;index++){
                            valArr.removeAt(0);
                        }
                    }
                    done=true;
                    counter=0;
                }
            }
            if(!done){
                Bundle["entry"] = valArr;
                //handler.PostData(postURL,Observe.JsonString(Bundle));
            }
        }
        else{
            qDebug()<<"Bundle Json (Observation) Open Error";
        }

        qDebug()<<"------------Molecular--------------"<<endl;
        //qDebug().noquote()<<MolecularJson.first()<<endl;
        //handler.PostData(postURL+"/MolecularSequence",MolecularJson.first());
        QFile file_Mol(BundlePath_Mol);
        if(file_Mol.open(QIODevice::ReadOnly | QIODevice::Text)){
            val = file_Mol.readAll();
            file_Obs.close();
            QJsonDocument doc = QJsonDocument::fromJson(val.toUtf8());
            Bundle  = doc.object();
            QJsonObject templateHolder = Bundle;
            QJsonArray nodeArray = Bundle["entry"].toArray();
            QJsonObject nodeTemplate = nodeArray[0].toObject();
            QJsonArray valArr;
            QJsonObject temp;
            for(int i=0;i<MolecularJson.size();i++){
                //form Molecular Bundle
                done=false;
                QJsonDocument convert = QJsonDocument::fromJson(MolecularJson[i].toUtf8());
                QJsonObject obj = convert.object();
                temp = nodeTemplate;
                temp["resource"] = obj;
                valArr.append(temp);
                counter++;
                if(counter==limit){
                    Bundle["entry"] = valArr;
                    //qDebug().noquote()<<Molecular.JsonString(Bundle);
                    //handler.PostData(postURL,Molecular.JsonString(Bundle));
                    Bundle = templateHolder;
                    nodeArray = Bundle["entry"].toArray();
                    nodeTemplate = nodeArray[0].toObject();
                    if(!valArr.empty()){
                        for(int index=0;index<counter;index++){
                            valArr.removeAt(0);
                        }
                    }
                    done=true;
                    counter=0;
                }
            }
            if(!done){
                Bundle["entry"] = valArr;
                //handler.PostData(postURL,Molecular.JsonString(Bundle));
            }
        }
        else{
            qDebug()<<"Bundle Json (Molecular) Open Error";
        }

        //response.write(reqBodyStr.toUtf8(),true);
        qDebug().noquote()<<"Observation : "+QString::number(ObserveJson.size())<<"Molecular : "+QString::number(MolecularJson.size())<<endl;
        //all datas from Observation and MolecularSequence done uploaded to server
    }
    else {
        response.setStatus(404,"Not found");
        response.write("The URL is wrong, no such document."+path,true);
    }
    qDebug("RequestMapper: finished request");
}
