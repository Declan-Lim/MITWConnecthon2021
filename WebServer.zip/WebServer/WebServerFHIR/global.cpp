#include "global.h"

//HttpSessionStore* sessionStore;
StaticFileController* staticFileController;
TemplateCache* templateCache;
