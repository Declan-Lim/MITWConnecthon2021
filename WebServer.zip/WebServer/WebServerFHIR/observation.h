#ifndef OBSERVATION_H
#define OBSERVATION_H

#include <QByteArray>
#include <QString>
#include <QMap>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QJsonDocument>
#include <QDebug>
#include <QDate>

class Observation
{
public:
    Observation();
    void ReadExampleJson(QString Path);
    void ReadLibrary(QString Path);
    void ReadCSV(QString Path);
    void Initialize(QString ID,QString SpecimenID ,QString Analysis,QString Genomic,QString Display);
    QString JsonString(QJsonObject ob);
    QJsonObject FormJson(QString Gene,QString Changed);
    QJsonObject example;
    QString example_str;
    QJsonObject library;//whole library
    QJsonArray libArray;//library inner ["docs"] data
    QStringList GCol,JCol;
    int current,RowCount;
  private:
    QString FindID(QString Gene);
    QString FindPrevID(QString Gene);
    QString tokenize(QString s);
};

#endif // OBSERVATION_H
