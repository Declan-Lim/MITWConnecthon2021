#include "molecularsequence.h"

molecularsequence::molecularsequence()
{
    Range = 0;
    Current =0;
}

void molecularsequence::ReadExampleJson(QString Path){
    QString val;
    QFile file(Path);
    if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
        val = file.readAll();
        file.close();
        QJsonDocument doc = QJsonDocument::fromJson(val.toUtf8());
        example  = doc.object();
        example_str = JsonString(example);
    }
    else{
        qDebug()<<"Read Molecular Sequence Example File Error";
    }
    //qDebug().noquote() << example_str;
}

void molecularsequence::ReadCSV(QString Path){
    QStringList splitList;
    QByteArray strArray;
    QString str;
    //ReadCSV
    DataSlot TempD;
    QFile file(Path);
    if(!file.open(QIODevice::ReadOnly)) qDebug()<<file.errorString();
    else{
        file.readLine();//Read title
        while(!file.atEnd()){
            strArray = file.readLine();
            str = QString(strArray);
            splitList=str.split(",");
            TempD.Chrom=splitList[0];
            TempD.Start=splitList[1];
            TempD.End=splitList[2];
            TempD.Ref=splitList[3];
            TempD.Alt=splitList[4];
            dataVal.push_back(TempD);
        }
        file.close();
    }
}

QString molecularsequence::JsonString(QJsonObject ob){
    QJsonDocument doc(ob);
    QByteArray arr = doc.toJson();
    return QString(arr);
}

QJsonObject molecularsequence::FormJson(DataSlot C,int index){
    QJsonObject root = example;
    QList<DataSlot> tempPlace;
    tempPlace.push_back(C);
    Current = index+1 ;
    DataSlot node;
    if(Current<dataVal.size()){
        for(int i=Current;i<dataVal.size();i++){
            node = dataVal[i];
            if(node.Start.toInt()>=(C.Start.toInt()-Range) && node.End.toInt()<=(C.End.toInt()+Range))
                tempPlace.push_back(node);
            else{
                Current = i;
                break;
            }
        }
    }
    QJsonObject refseq = root["referenceSeq"].toObject();
    QJsonObject ch = refseq["chromosome"].toObject();
    QJsonArray coding = ch["coding"].toArray();
    for(int k=0;k<coding.count();k++){
        QJsonObject ob = coding[k].toObject();
        if(ob.contains("code")){
            ob["code"]=C.Chrom;
            ob["display"] = "chromosome "+C.Chrom;
            coding[k]=ob;
        }
    }
    QJsonObject variant = root["variant"].toObject();
    // need to form array
    QJsonArray varArr;
    for(int i=0;i<tempPlace.size();i++){
        node = tempPlace[i];
        QJsonObject repl = variant;
        repl["start"]=node.Start;
        repl["end"]=node.End;
        repl["referenceAllele"]=node.Ref;
        repl["observedAllele"]=node.Alt;
        varArr.append(repl);
   }
   root["variant"]=varArr;
   ch["coding"]=coding;
   refseq["chromosome"]=ch;
   refseq["windowStart"] = C.Start.toInt()-Range;
   refseq["windowEnd"] = C.End.toInt()+Range;
   root["referenceSeq"] = refseq;
   return root;
}

void molecularsequence::Initialize(QString ID,QString SpecimenID,QString Sequence,QString Genome,QString WindowRange,QString Coordinate,QString Strand){
    Range = WindowRange.toInt();//molecularSequence.range
    QJsonObject patient = example["patient"].toObject();
    patient["reference"]="Patient/"+ID;
    example["patient"]=patient;
    QJsonObject specimen = example["specimen"].toObject();
    specimen["reference"] = "Specimen/"+SpecimenID; // Specimen ID
    example["specimen"]=specimen;
    example["type"]=Sequence; //Sequence type
    QJsonObject refSeq = example["referenceSeq"].toObject();
    refSeq["genomeBuild"] = Genome; //MolecularSequence.ReferenceSeq.genomeBuild
    refSeq["strand"] = Strand; //MolecularSequence.ReferenceSeq.strand
    example["referenceSeq"] = refSeq;
    example["coordinateSystem"] = Coordinate; //MolecularSequence.coordinateSystem
    example_str = JsonString(example);
}

/*QJsonObject root = example;

    QList<DataSlot> tempPlace;
    tempPlace.push_back(C);
    DataSlot node;
    int tmp = Current;
    for(int i=tmp+1;i<dataVal.size();i++){
        //convert start and End of dataVal[i] then see if within the range
        node = dataVal[i];
        if(node.Start.toInt()>=(C.Start.toInt()-Range) && node.End.toInt()<=(C.End.toInt()+Range)){
            tempPlace.push_back(node);
            Current=i;
        }
        else break;
    }
    */
