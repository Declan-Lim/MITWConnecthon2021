#include "net.h"
//https://stackoverflow.com/questions/25433706/qt-console-app-using-qnetworkaccessmanager
Net::Net()
{

}

/*void Net::requestFinished(QNetworkReply *reply)
{
    QVariant statusCode = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute);
    if(statusCode.isValid())
      qDebug().noquote()<<"status code="+QString::number(statusCode.toInt());
    QVariant reason = reply->attribute(QNetworkRequest::HttpReasonPhraseAttribute).toString();
    if(reason.isValid())
      qDebug().noquote()<<reason.toString();
    QNetworkReply::NetworkError err = reply->error();
    if(err != QNetworkReply::NoError) {
       qDebug().noquote()<<"Failed: " +reply->errorString();
     }
     else {
       // 獲取返回內容
      qDebug().noquote()<<reply->readAll()<<endl;
    }
}*/

void Net::PostData(QString url,QString Value)
{
    QUrl theUrl(url);
    QNetworkRequest request(theUrl);
    QString token = "d214cdee-9783-43e1-a7e8-63c2b17010fd";
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json+fhir");
    request.setRawHeader(QByteArray("Authorization"),"Bearer "+token.toUtf8());
    //manager->post(request,Value.toUtf8());
    QEventLoop loop;
    QNetworkReply* reply = manager.post(request, Value.toUtf8());
    connect(reply , SIGNAL(finished()), &loop, SLOT(quit()));
    loop.exec();
    QVariant statusCode = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute);
    if(statusCode.isValid())
      qDebug().noquote()<<"status code="+QString::number(statusCode.toInt());
    QVariant reason = reply->attribute(QNetworkRequest::HttpReasonPhraseAttribute).toString();
    if(reason.isValid())
      qDebug().noquote()<<reason.toString();
    QNetworkReply::NetworkError err = reply->error();
    if(err != QNetworkReply::NoError) {
       qDebug().noquote()<<"Failed: " +reply->errorString();
     }
     else {
       // 獲取返回內容
      qDebug().noquote()<<reply->readAll()<<endl;
    }
}
