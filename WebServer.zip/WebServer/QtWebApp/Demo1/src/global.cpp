/**
  @file
  @author Stefan Frings
*/

#include "global.h"

TemplateCache* templateCache;
HttpSessionStore* sessionStore;
StaticFileController* staticFileController;
FileLogger* logger;
