var classQtServiceControllerHandler =
[
    [ "QtServiceControllerHandler", "classQtServiceControllerHandler.html#aececaafe4c1381e632ff5da78187d136", null ],
    [ "customEvent", "classQtServiceControllerHandler.html#a92e2fafac640400c4defe718024f5340", null ]
];