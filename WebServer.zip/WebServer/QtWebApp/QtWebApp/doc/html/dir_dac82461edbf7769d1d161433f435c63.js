var dir_dac82461edbf7769d1d161433f435c63 =
[
    [ "dualfilelogger.cpp", "dualfilelogger_8cpp.html", null ],
    [ "dualfilelogger.h", "dualfilelogger_8h.html", [
      [ "DualFileLogger", "classstefanfrings_1_1DualFileLogger.html", "classstefanfrings_1_1DualFileLogger" ]
    ] ],
    [ "filelogger.cpp", "filelogger_8cpp.html", null ],
    [ "filelogger.h", "filelogger_8h.html", [
      [ "FileLogger", "classstefanfrings_1_1FileLogger.html", "classstefanfrings_1_1FileLogger" ]
    ] ],
    [ "logger.cpp", "logger_8cpp.html", null ],
    [ "logger.h", "logger_8h.html", [
      [ "Logger", "classstefanfrings_1_1Logger.html", "classstefanfrings_1_1Logger" ]
    ] ],
    [ "logglobal.h", "logglobal_8h.html", "logglobal_8h" ],
    [ "logmessage.cpp", "logmessage_8cpp.html", null ],
    [ "logmessage.h", "logmessage_8h.html", [
      [ "LogMessage", "classstefanfrings_1_1LogMessage.html", "classstefanfrings_1_1LogMessage" ]
    ] ]
];