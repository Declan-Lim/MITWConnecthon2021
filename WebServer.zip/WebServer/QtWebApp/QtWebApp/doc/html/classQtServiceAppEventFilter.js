var classQtServiceAppEventFilter =
[
    [ "QtServiceAppEventFilter", "classQtServiceAppEventFilter.html#a16ec19a16f46518d7f1b5a1eb21da854", null ],
    [ "nativeEventFilter", "classQtServiceAppEventFilter.html#ad4fdf35325a09691aa863cfcd9014611", null ]
];