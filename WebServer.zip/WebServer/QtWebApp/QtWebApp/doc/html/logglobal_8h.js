var logglobal_8h =
[
    [ "DECLSPEC", "logglobal_8h.html#aa4c7a931f4a968f818b2a1b10a432185", null ],
    [ "nullptr", "logglobal_8h.html#ab979d9d4b4923f7c54d6caa6e1a61936", null ]
];