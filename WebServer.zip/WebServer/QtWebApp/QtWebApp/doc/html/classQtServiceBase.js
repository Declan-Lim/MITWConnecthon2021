var classQtServiceBase =
[
    [ "MessageType", "classQtServiceBase.html#acffd9389fe7178bf1f35d8bf3dae1095", [
      [ "Success", "classQtServiceBase.html#acffd9389fe7178bf1f35d8bf3dae1095afb2ada59803d0e000106b41b6d5127d4", null ],
      [ "Error", "classQtServiceBase.html#acffd9389fe7178bf1f35d8bf3dae1095a78136902bf4b447146b9cf9032bb18e7", null ],
      [ "Warning", "classQtServiceBase.html#acffd9389fe7178bf1f35d8bf3dae1095a4b54741a94722a7a63e737e2d25873ed", null ],
      [ "Information", "classQtServiceBase.html#acffd9389fe7178bf1f35d8bf3dae1095a84e71978b571923b18bf2f72d94e7e02", null ]
    ] ],
    [ "ServiceFlag", "classQtServiceBase.html#af6e74a87329ef64760783364538e5d51", [
      [ "Default", "classQtServiceBase.html#af6e74a87329ef64760783364538e5d51a4d96fbb4f188ad226630c426184e1d7e", null ],
      [ "CanBeSuspended", "classQtServiceBase.html#af6e74a87329ef64760783364538e5d51af3246f46860cdfe45055cc47381fcc7a", null ],
      [ "CannotBeStopped", "classQtServiceBase.html#af6e74a87329ef64760783364538e5d51aaabef7aa1d1a451bf240546d3d8fc2ba", null ],
      [ "NeedsStopOnShutdown", "classQtServiceBase.html#af6e74a87329ef64760783364538e5d51a6bc13130f21bc2ec7fe9253c7f1b3a81", null ]
    ] ],
    [ "QtServiceBase", "classQtServiceBase.html#a75e3f82739df6dc0b9aa899b3f9552eb", null ],
    [ "~QtServiceBase", "classQtServiceBase.html#a82c0872e5ed2448eff9eb6521f75bfd2", null ],
    [ "createApplication", "classQtServiceBase.html#ac5ae73935f489282b35c70b27b341390", null ],
    [ "exec", "classQtServiceBase.html#afae2e589de71c1ae3ae8db3dc9ab9c64", null ],
    [ "executeApplication", "classQtServiceBase.html#ab70633cd29a22758dfa0502b77e564f6", null ],
    [ "logMessage", "classQtServiceBase.html#ac071ce0b30547e17c3b3ca9dcb0108c9", null ],
    [ "pause", "classQtServiceBase.html#a43215a7c5c047d30bcf4f697e6691f89", null ],
    [ "processCommand", "classQtServiceBase.html#a47485f00f6eba0758d2ffc75092295cf", null ],
    [ "resume", "classQtServiceBase.html#aaa2e05ef1c36283b6b35348c3972b489", null ],
    [ "serviceDescription", "classQtServiceBase.html#a6cf3ef7bc5d85acb31e99a85fde47397", null ],
    [ "serviceFlags", "classQtServiceBase.html#aab0b204981c481e098fe72061e3f367a", null ],
    [ "serviceName", "classQtServiceBase.html#a643f253b3931e6a6c4e8caa190756214", null ],
    [ "setServiceDescription", "classQtServiceBase.html#a09d7547436c65a900f18c58b2a650286", null ],
    [ "setServiceFlags", "classQtServiceBase.html#a3f8a07d0cf536720e7fcf1ec562635d1", null ],
    [ "setStartupType", "classQtServiceBase.html#a6beddd54c973c3a7d81075b2f3f80df2", null ],
    [ "start", "classQtServiceBase.html#adbc0cd621b41bd3a6a1f62fda432e9e4", null ],
    [ "startupType", "classQtServiceBase.html#aa1b3bf9b7fc09777b422f49f7bcfbcbe", null ],
    [ "stop", "classQtServiceBase.html#a8d52c1b8fd06b50bdc0a0c6f9936a68e", null ],
    [ "QtServiceSysPrivate", "classQtServiceBase.html#a3101d1ae35029ba305c82b8f49512d6f", null ]
];