var classstefanfrings_1_1HttpSessionStore =
[
    [ "HttpSessionStore", "classstefanfrings_1_1HttpSessionStore.html#a6fe27af9d600bdb5981ce10587ad84dd", null ],
    [ "~HttpSessionStore", "classstefanfrings_1_1HttpSessionStore.html#a06062155c1dc31ede2cbc5f31bce4df3", null ],
    [ "getSession", "classstefanfrings_1_1HttpSessionStore.html#ab197132dc4713cd647705d09c9f84ba8", null ],
    [ "getSession", "classstefanfrings_1_1HttpSessionStore.html#af8b334fa7cf51e411039f0256eda90d6", null ],
    [ "getSessionId", "classstefanfrings_1_1HttpSessionStore.html#aaf9147137698db03b322ea93de548fba", null ],
    [ "removeSession", "classstefanfrings_1_1HttpSessionStore.html#a34db6bdec51d2e6f68528391a36165f4", null ],
    [ "sessionDeleted", "classstefanfrings_1_1HttpSessionStore.html#ace45645f705afa06389fb62b78dcc069", null ],
    [ "sessions", "classstefanfrings_1_1HttpSessionStore.html#a25bcdad5accd436881927a414b99ba22", null ]
];